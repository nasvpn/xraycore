# Xray-core
Support:
• Custom method
• Dynamic Path for websocket


