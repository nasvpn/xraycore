// Package buf provides a light-weight memory allocation mechanism.
package buf // import "github.com/dharak36/xray-core/common/buf"

//go:generate go run github.com/dharak36/xray-core/common/errors/errorgen
