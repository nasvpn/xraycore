package mux

//go:generate go run github.com/dharak36/xray-core/common/errors/errorgen
