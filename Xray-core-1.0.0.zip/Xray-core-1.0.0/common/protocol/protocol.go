package protocol // import "github.com/dharak36/xray-core/common/protocol"

//go:generate go run github.com/dharak36/xray-core/common/errors/errorgen
