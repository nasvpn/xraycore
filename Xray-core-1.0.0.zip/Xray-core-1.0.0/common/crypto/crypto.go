// Package crypto provides common crypto libraries for Xray.
package crypto // import "github.com/dharak36/xray-core/common/crypto"

//go:generate go run github.com/dharak36/xray-core/common/errors/errorgen
