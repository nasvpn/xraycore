// Package policy is an implementation of policy.Manager feature.
package policy

//go:generate go run github.com/dharak36/xray-core/common/errors/errorgen
